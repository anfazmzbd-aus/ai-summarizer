class NullSubscriber:
    pass
